﻿using System;
using System.Globalization;

public class ArrayHandler
{

    // закрите поле масиву
    private double[] _array;

    // прописування масива з 30 доступних нам значень
    public ArrayHandler(double[] array)

    {
        if (array.Length != 30)
            throw new ArgumentException("масив повинен містити 30 елементів");
        _array = array;
    }

    // властивість доступу до масиву
    public double[] Array

    {
        get { return _array; }
    }

    // iндексатор необхiдний для доступу до елементiв 
    public double this[int index]

    {
        get
        {
            if (index < 0 || index >= _array.Length)
                throw new IndexOutOfRangeException("індекс поза зоною масиву");
            return _array[index];
        }
        set
        {
            if (index < 0 || index >= _array.Length)
                throw new IndexOutOfRangeException("індекс поза зоною масиву");
            _array[index] = value;
        }
    }

    // метод, завдяки якому ми зможемо провести пошук суми парних та непарних елементiв

    public (double S_p, double S_np) CalculateSums()

    {
        double S_p = 0; // сума парних елементiв
        double S_np = 0; // сума непарних елементiв
        for (int i = 0; i < _array.Length; i++)
        {
            if ((int)_array[i] % 2 == 0) // парний iндекс
            {
                S_p += _array[i];
            }
            else // непарний iндекс
            {
                S_np += _array[i];
            }
        }
        return (S_p, S_np);
    }
}

class Program
{
    static void Main()
    {
        double[] values = new double[30];
        bool validInput = false;
        Console.WriteLine("введiть 30 числових значень з використанням коми або пробiлу :");
        while (!validInput)

        {
            string input = Console.ReadLine();
            string[] inputs = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (inputs.Length == 30 && inputs.All(x => double.TryParse(x, NumberStyles.Any, CultureInfo.CurrentCulture, out _)))
            {
                // тут, якщо всi числа коректнi, почнеться заповнення масиву (я сподiваюся)
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = double.Parse(inputs[i], CultureInfo.CurrentCulture);
                }
                validInput = true;
            }
            else
            {
                Console.WriteLine("помилка!! введiть тiльки 30 чисел, не менш та не бiльш, роздiлених пробiлом/комою!");
            }
        }

        ArrayHandler arrayHandler = new ArrayHandler(values);
        var (S_p, S_np) = arrayHandler.CalculateSums();
        Console.WriteLine($"сума парних елементiв: {Math.Round(S_p, 2)}");
        Console.WriteLine($"сума непарних елементiв: {Math.Round(S_np, 2)}");
    }
}
// програма просить користувача ввести випадковi значення у виглядi 30 штук чисел, а потiм виходить сума з округленням (щоб не виходило занадто велике число).